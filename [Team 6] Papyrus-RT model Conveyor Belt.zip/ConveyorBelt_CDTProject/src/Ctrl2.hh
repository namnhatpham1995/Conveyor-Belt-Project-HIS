
#ifndef CTRL2_HH
#define CTRL2_HH

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Ctrl2 : public UMLRTCapsule
{
public:
    Capsule_Ctrl2( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    UMLRTLogProtocol_baserole log;
    ClientMain::Base main;
public:
    enum BorderPortId
    {
        borderport_main,
        borderport_sensor2
    };
protected:
    ClientClient::Conj sensor2;
    UMLRTTimerProtocol_baserole timingC2;
public:
    enum InternalPortId
    {
        internalport_timingC2,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_log,
        port_main,
        port_sensor2,
        port_timingC2
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        WorkingC2,
        WorkingC2__Countdown,
        WorkingC2__WaitM,
        WorkingC2__boundary,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[6];
    State currentState;
    State history[1];
    void save_history( State compositeState, State subState );
    bool check_history( State compositeState, State subState );
    void update_state( State newState );
    void transitionaction_____WorkingC2__startCtrl( const UMLRTMessage * msg );
    void transitionaction_____WorkingC2__transition0( const UMLRTMessage * msg );
    void transitionaction_____WorkingC2__transition2( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__new_transition_1( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__new_transition_2( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__new_transition_4_to_visited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__startCtrl( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__transition0( const UMLRTMessage * msg );
    void actionchain_____WorkingC2__transition2( const UMLRTMessage * msg );
    State junction_____WorkingC2__connectionPoint0( const UMLRTMessage * msg );
    State choice_____WorkingC2__deephistory( const UMLRTMessage * msg );
    State state_____WorkingC2__Countdown( const UMLRTMessage * msg );
    State state_____WorkingC2__WaitM( const UMLRTMessage * msg );
    State state_____WorkingC2__boundary( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass Ctrl2;

#endif

