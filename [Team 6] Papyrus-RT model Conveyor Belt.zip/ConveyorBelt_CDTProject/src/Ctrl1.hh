
#ifndef CTRL1_HH
#define CTRL1_HH

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Ctrl1 : public UMLRTCapsule
{
public:
    Capsule_Ctrl1( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    UMLRTLogProtocol_baserole log;
    ClientMain::Base main;
public:
    enum BorderPortId
    {
        borderport_main,
        borderport_sensor1
    };
protected:
    ClientClient::Conj sensor1;
    UMLRTTimerProtocol_baserole timingC1;
public:
    enum InternalPortId
    {
        internalport_timingC1,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_log,
        port_main,
        port_sensor1,
        port_timingC1
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        WorkingC1,
        WorkingC1__Countdown,
        WorkingC1__WaitM,
        WorkingC1__boundary,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[6];
    State currentState;
    State history[1];
    void save_history( State compositeState, State subState );
    bool check_history( State compositeState, State subState );
    void update_state( State newState );
    void transitionaction_____WorkingC1__startCtrl( const UMLRTMessage * msg );
    void transitionaction_____WorkingC1__transition0( const UMLRTMessage * msg );
    void transitionaction_____WorkingC1__transition2( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__new_transition_1( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__new_transition_2( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__new_transition_4_to_visited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__startCtrl( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__transition0( const UMLRTMessage * msg );
    void actionchain_____WorkingC1__transition2( const UMLRTMessage * msg );
    State junction_____WorkingC1__connectionPoint0( const UMLRTMessage * msg );
    State choice_____WorkingC1__deephistory( const UMLRTMessage * msg );
    State state_____WorkingC1__Countdown( const UMLRTMessage * msg );
    State state_____WorkingC1__WaitM( const UMLRTMessage * msg );
    State state_____WorkingC1__boundary( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass Ctrl1;

#endif

