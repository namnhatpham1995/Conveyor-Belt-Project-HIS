
#include "Top.hh"

#include "Ctrl1.hh"
#include "Ctrl2.hh"
#include "MainCtrl.hh"
#include "Sensor1.hh"
#include "Sensor2.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtcapsulepart.hh"
#include "umlrtcommsport.hh"
#include "umlrtframeservice.hh"
#include "umlrtslot.hh"
#include <cstddef>
#include "umlrtcapsulerole.hh"
class UMLRTRtsInterface;

Capsule_Top::Capsule_Top( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, ctrl1( &slot->parts[part_ctrl1] )
, ctrl2( &slot->parts[part_ctrl2] )
, mainCtrl( &slot->parts[part_mainCtrl] )
, sensor1( &slot->parts[part_sensor1] )
, sensor2( &slot->parts[part_sensor2] )
{
}







void Capsule_Top::bindPort( bool isBorder, int portId, int index )
{
}

void Capsule_Top::unbindPort( bool isBorder, int portId, int index )
{
}

void Capsule_Top::initialize( const UMLRTMessage & msg )
{
}

void Capsule_Top::inject( const UMLRTMessage & msg )
{
}


static const UMLRTCapsuleRole roles[] = 
{
    {
        "ctrl1",
        &Ctrl1,
        1,
        1,
        false,
        false
    },
    {
        "ctrl2",
        &Ctrl2,
        1,
        1,
        false,
        false
    },
    {
        "mainCtrl",
        &MainCtrl,
        1,
        1,
        false,
        false
    },
    {
        "sensor1",
        &Sensor1,
        1,
        1,
        false,
        false
    },
    {
        "sensor2",
        &Sensor2,
        1,
        1,
        false,
        false
    }
};

static void instantiate_Top( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_ctrl1].slots[0]->ports[Capsule_Ctrl1::borderport_main], 0, &slot->parts[Capsule_Top::part_mainCtrl].slots[0]->ports[Capsule_MainCtrl::borderport_ctrl1], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_ctrl1].slots[0]->ports[Capsule_Ctrl1::borderport_sensor1], 0, &slot->parts[Capsule_Top::part_sensor1].slots[0]->ports[Capsule_Sensor1::borderport_ctrl1], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_ctrl2].slots[0]->ports[Capsule_Ctrl2::borderport_main], 0, &slot->parts[Capsule_Top::part_mainCtrl].slots[0]->ports[Capsule_MainCtrl::borderport_ctrl2], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_ctrl2].slots[0]->ports[Capsule_Ctrl2::borderport_sensor2], 0, &slot->parts[Capsule_Top::part_sensor2].slots[0]->ports[Capsule_Sensor2::borderport_ctrl2], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_mainCtrl].slots[0]->ports[Capsule_MainCtrl::borderport_sensor1], 0, &slot->parts[Capsule_Top::part_sensor1].slots[0]->ports[Capsule_Sensor1::borderport_main], 0 );
    UMLRTFrameService::connectPorts( &slot->parts[Capsule_Top::part_mainCtrl].slots[0]->ports[Capsule_MainCtrl::borderport_sensor2], 0, &slot->parts[Capsule_Top::part_sensor2].slots[0]->ports[Capsule_Sensor2::borderport_main], 0 );
    Ctrl1.instantiate( NULL, slot->parts[Capsule_Top::part_ctrl1].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_ctrl1].slots[0], Ctrl1.numPortRolesBorder ) );
    Ctrl2.instantiate( NULL, slot->parts[Capsule_Top::part_ctrl2].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_ctrl2].slots[0], Ctrl2.numPortRolesBorder ) );
    MainCtrl.instantiate( NULL, slot->parts[Capsule_Top::part_mainCtrl].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_mainCtrl].slots[0], MainCtrl.numPortRolesBorder ) );
    Sensor1.instantiate( NULL, slot->parts[Capsule_Top::part_sensor1].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_sensor1].slots[0], Sensor1.numPortRolesBorder ) );
    Sensor2.instantiate( NULL, slot->parts[Capsule_Top::part_sensor2].slots[0], UMLRTFrameService::createBorderPorts( slot->parts[Capsule_Top::part_sensor2].slots[0], Sensor2.numPortRolesBorder ) );
    slot->capsule = new Capsule_Top( &Top, slot, borderPorts, NULL, false );
}

const UMLRTCapsuleClass Top = 
{
    "Top",
    NULL,
    instantiate_Top,
    5,
    roles,
    0,
    NULL,
    0,
    NULL
};

