
#ifndef SENSOR2_HH
#define SENSOR2_HH

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
#include "umlrttimespec.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Sensor2 : public UMLRTCapsule
{
public:
    Capsule_Sensor2( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    ClientClient::Base ctrl2;
public:
    enum BorderPortId
    {
        borderport_ctrl2,
        borderport_main
    };
protected:
    UMLRTLogProtocol_baserole log;
    ClientMain::Base main;
    UMLRTTimerProtocol_baserole timingS2;
public:
    enum InternalPortId
    {
        internalport_timingS2,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_ctrl2,
        port_log,
        port_main,
        port_timingS2
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    int hitCount2;
    UMLRTTimespec begin2;
    UMLRTTimespec line2;
    UMLRTTimespec end2;
    UMLRTTimespec line2end;
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        WorkingS2,
        WorkingS2__WaitCtrl2,
        WorkingS2__WaitPackage2,
        WorkingS2__boundary,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[6];
    State currentState;
    State history[1];
    void save_history( State compositeState, State subState );
    bool check_history( State compositeState, State subState );
    void update_state( State newState );
    void entryaction_____WorkingS2( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__receiveConfirm( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__requestAgain( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__transition0( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__transition1( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__transition4( const UMLRTMessage * msg );
    void transitionaction_____WorkingS2__transition5( const UMLRTMessage * msg );
    bool guard_____WorkingS2__transition4( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__new_transition_1( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__new_transition_2( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__new_transition_4_to_visited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__receiveConfirm( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__requestAgain( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__transition0( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__transition1( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__transition4( const UMLRTMessage * msg );
    void actionchain_____WorkingS2__transition5( const UMLRTMessage * msg );
    State junction_____WorkingS2__connectionPoint0( const UMLRTMessage * msg );
    State choice_____WorkingS2__deephistory( const UMLRTMessage * msg );
    State choice_____WorkingS2__subvertex2( const UMLRTMessage * msg );
    State state_____WorkingS2__WaitCtrl2( const UMLRTMessage * msg );
    State state_____WorkingS2__WaitPackage2( const UMLRTMessage * msg );
    State state_____WorkingS2__boundary( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass Sensor2;

#endif

