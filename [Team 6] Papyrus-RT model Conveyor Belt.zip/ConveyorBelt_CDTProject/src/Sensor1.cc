
#include "Sensor1.hh"

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Sensor1::Capsule_Sensor1( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, ctrl1( borderPorts[borderport_ctrl1] )
, main( borderPorts[borderport_main] )
, timingS( internalPorts[internalport_timingS] )
, hitCount( 1 )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[WorkingS1] = "WorkingS1";
    stateNames[WorkingS1__WaitCtrl] = "WorkingS1__WaitCtrl";
    stateNames[WorkingS1__WaitPackage] = "WorkingS1__WaitPackage";
    stateNames[WorkingS1__boundary] = "WorkingS1__boundary";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
    int i = 0;
    while( i < 1 )
        history[i++] = SPECIAL_INTERNAL_STATE_UNVISITED;
}









void Capsule_Sensor1::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl1, index, true );
            break;
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, true );
            break;
        }
}

void Capsule_Sensor1::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl1, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_ctrl1], index );
            break;
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_main], index );
            break;
        }
}






void Capsule_Sensor1::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case WorkingS1__WaitPackage:
        currentState = state_____WorkingS1__WaitPackage( &message );
        break;
    case WorkingS1__WaitCtrl:
        currentState = state_____WorkingS1__WaitCtrl( &message );
        break;
    case WorkingS1__boundary:
        currentState = state_____WorkingS1__boundary( &message );
        break;
    default:
        break;
    }
}

void Capsule_Sensor1::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = junction_____WorkingS1__connectionPoint0( &message );
}

const char * Capsule_Sensor1::getCurrentStateString() const
{
    return stateNames[currentState];
}





void Capsule_Sensor1::save_history( Capsule_Sensor1::State compositeState, Capsule_Sensor1::State subState )
{
    history[compositeState] = subState;
}

bool Capsule_Sensor1::check_history( Capsule_Sensor1::State compositeState, Capsule_Sensor1::State subState )
{
    return history[compositeState] == subState;
}

void Capsule_Sensor1::update_state( Capsule_Sensor1::State newState )
{
    currentState = newState;
}

void Capsule_Sensor1::transitionaction_____WorkingS1__receiveConfirm( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::WaitCtrl,WorkingS1::subvertex2,confirm:ctrl1 */
    UMLRTTimespec::getclock(&end1);
    log.show("Line 1 load successfully at ");
    log.log(end1.tv_sec-line1.tv_sec);
    log.show("Line 1 load successfully after: ");
    log.log(end1.tv_sec-begin1.tv_sec);
    log.log("--------------------------------------------------------------------");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::transitionaction_____WorkingS1__requestAgain( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::WaitCtrl,WorkingS1::WaitCtrl,reply:main */
    log.log("Line 1: request again!");
    main.request().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::transitionaction_____WorkingS1__transition0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::connectionPoint0,WorkingS1::WaitPackage */
    UMLRTTimespec::getclock(&line1);
    log.log("Starting sensor 1 at ");
    log.log(line1.tv_sec-line1.tv_sec);
    timingS.informIn(UMLRTTimespec((rand()%3)+1, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::transitionaction_____WorkingS1__transition1( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::WaitPackage,WorkingS1::WaitCtrl,timeout:timingS */
    UMLRTTimespec::getclock(&begin1);
    log.show("Line 1: Package "); log.show(hitCount); log.show(" at: ");
    log.log(begin1.tv_sec-line1.tv_sec);
    main.request().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::transitionaction_____WorkingS1__transition4( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::subvertex2,WorkingS1::WaitPackage */
    timingS.informIn(UMLRTTimespec((rand()%7)+1, 0));
    hitCount++;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::transitionaction_____WorkingS1__transition5( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 transition WorkingS1::subvertex2,WorkingS1 */
    UMLRTTimespec::getclock(&line1end);
    log.show( "Line 1 ends after ");
    log.log(line1end.tv_sec-line1.tv_sec);
    log.log( "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

bool Capsule_Sensor1::guard_____WorkingS1__transition4( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor1::WorkingS1 guard WorkingS1::subvertex2,WorkingS1::WaitPackage */
    return hitCount <5;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor1::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( WorkingS1 );
}

void Capsule_Sensor1::actionchain_____WorkingS1__new_transition_1( const UMLRTMessage * msg )
{
    update_state( WorkingS1__WaitPackage );
}

void Capsule_Sensor1::actionchain_____WorkingS1__new_transition_2( const UMLRTMessage * msg )
{
    update_state( WorkingS1__WaitCtrl );
}

void Capsule_Sensor1::actionchain_____WorkingS1__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingS1__boundary );
}

void Capsule_Sensor1::actionchain_____WorkingS1__new_transition_4_to_visited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingS1__boundary );
}

void Capsule_Sensor1::actionchain_____WorkingS1__receiveConfirm( const UMLRTMessage * msg )
{
    update_state( WorkingS1 );
    transitionaction_____WorkingS1__receiveConfirm( msg );
}

void Capsule_Sensor1::actionchain_____WorkingS1__requestAgain( const UMLRTMessage * msg )
{
    update_state( WorkingS1 );
    transitionaction_____WorkingS1__requestAgain( msg );
    update_state( WorkingS1__WaitCtrl );
}

void Capsule_Sensor1::actionchain_____WorkingS1__transition0( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS1__transition0( msg );
    update_state( WorkingS1__WaitPackage );
}

void Capsule_Sensor1::actionchain_____WorkingS1__transition1( const UMLRTMessage * msg )
{
    update_state( WorkingS1 );
    transitionaction_____WorkingS1__transition1( msg );
    update_state( WorkingS1__WaitCtrl );
}

void Capsule_Sensor1::actionchain_____WorkingS1__transition4( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS1__transition4( msg );
    update_state( WorkingS1__WaitPackage );
}

void Capsule_Sensor1::actionchain_____WorkingS1__transition5( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS1__transition5( msg );
}

Capsule_Sensor1::State Capsule_Sensor1::junction_____WorkingS1__connectionPoint0( const UMLRTMessage * msg )
{
    actionchain_____WorkingS1__transition0( msg );
    return WorkingS1__WaitPackage;
}

Capsule_Sensor1::State Capsule_Sensor1::choice_____WorkingS1__deephistory( const UMLRTMessage * msg )
{
    if( check_history( WorkingS1, WorkingS1__WaitPackage ) )
    {
        actionchain_____WorkingS1__new_transition_1( msg );
        return WorkingS1__WaitPackage;
    }
    else if( check_history( WorkingS1, WorkingS1__WaitCtrl ) )
    {
        actionchain_____WorkingS1__new_transition_2( msg );
        return WorkingS1__WaitCtrl;
    }
    else if( check_history( WorkingS1, SPECIAL_INTERNAL_STATE_UNVISITED ) )
    {
        actionchain_____WorkingS1__new_transition_3_to_unvisited_boundary( msg );
        return WorkingS1__boundary;
    }
    else if( check_history( WorkingS1, WorkingS1__boundary ) )
    {
        actionchain_____WorkingS1__new_transition_4_to_visited_boundary( msg );
        return WorkingS1__boundary;
    }
    return currentState;
}

Capsule_Sensor1::State Capsule_Sensor1::choice_____WorkingS1__subvertex2( const UMLRTMessage * msg )
{
    if( guard_____WorkingS1__transition4( msg ) )
    {
        actionchain_____WorkingS1__transition4( msg );
        return WorkingS1__WaitPackage;
    }
    else
    {
        actionchain_____WorkingS1__transition5( msg );
        return choice_____WorkingS1__deephistory( msg );
    }
    return currentState;
}

Capsule_Sensor1::State Capsule_Sensor1::state_____WorkingS1__WaitCtrl( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_ctrl1:
        switch( msg->getSignalId() )
        {
        case ClientClient::signal_confirm:
            actionchain_____WorkingS1__receiveConfirm( msg );
            return choice_____WorkingS1__subvertex2( msg );
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    case port_main:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_reply:
            actionchain_____WorkingS1__requestAgain( msg );
            return WorkingS1__WaitCtrl;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor1::State Capsule_Sensor1::state_____WorkingS1__WaitPackage( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingS:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____WorkingS1__transition1( msg );
            return WorkingS1__WaitCtrl;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor1::State Capsule_Sensor1::state_____WorkingS1__boundary( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Sensor1::port_ctrl1,
        "ClientClient",
        "ctrl1",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Sensor1::port_main,
        "ClientMain",
        "main",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Sensor1::port_timingS,
        "Timing",
        "timingS",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_Sensor1::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Sensor1( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Sensor1 );
    slot->capsule = new Capsule_Sensor1( &Sensor1, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Sensor1 = 
{
    "Sensor1",
    NULL,
    instantiate_Sensor1,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

