
#include "TopControllers.hh"

#include "Ctrl1.hh"
#include "Ctrl2.hh"
#include "MainCtrl.hh"
#include "Sensor1.hh"
#include "Sensor2.hh"
#include "Top.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtcapsulepart.hh"
#include "umlrtcommsport.hh"
#include "umlrtcommsportfarend.hh"
#include "umlrtcontroller.hh"
#include "umlrtslot.hh"
#include <cstddef>


static UMLRTController DefaultController_( "DefaultController" );

UMLRTController * DefaultController = &DefaultController_;

static Capsule_Top top( &Top, &Top_slots[InstId_Top], NULL, NULL, true );

static UMLRTSlot * slots_Top[] = 
{
    &Top_slots[InstId_Top_ctrl1],
    &Top_slots[InstId_Top_ctrl2],
    &Top_slots[InstId_Top_mainCtrl],
    &Top_slots[InstId_Top_sensor1],
    &Top_slots[InstId_Top_sensor2]
};

static UMLRTCapsulePart parts_Top[] = 
{
    {
        &Top,
        Capsule_Top::part_ctrl1,
        1,
        &slots_Top[0]
    },
    {
        &Top,
        Capsule_Top::part_ctrl2,
        1,
        &slots_Top[1]
    },
    {
        &Top,
        Capsule_Top::part_mainCtrl,
        1,
        &slots_Top[2]
    },
    {
        &Top,
        Capsule_Top::part_sensor1,
        1,
        &slots_Top[3]
    },
    {
        &Top,
        Capsule_Top::part_sensor2,
        1,
        &slots_Top[4]
    }
};

static UMLRTCommsPortFarEnd borderfarEndList_Top_ctrl1[] = 
{
    {
        0,
        &borderports_Top_mainCtrl[Capsule_MainCtrl::borderport_ctrl1]
    },
    {
        0,
        &borderports_Top_sensor1[Capsule_Sensor1::borderport_ctrl1]
    }
};

UMLRTCommsPort borderports_Top_ctrl1[] = 
{
    {
        &Ctrl1,
        Capsule_Ctrl1::borderport_main,
        &Top_slots[InstId_Top_ctrl1],
        1,
        borderfarEndList_Top_ctrl1,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Ctrl1,
        Capsule_Ctrl1::borderport_sensor1,
        &Top_slots[InstId_Top_ctrl1],
        1,
        &borderfarEndList_Top_ctrl1[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_ctrl1_ptrs[] = 
{
    &borderports_Top_ctrl1[0],
    &borderports_Top_ctrl1[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_ctrl1[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_ctrl1[] = 
{
    {
        &Ctrl1,
        Capsule_Ctrl1::internalport_timingC1,
        &Top_slots[InstId_Top_ctrl1],
        1,
        &internalfarEndList_Top_ctrl1[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &Ctrl1,
        Capsule_Ctrl1::internalport_log,
        &Top_slots[InstId_Top_ctrl1],
        1,
        internalfarEndList_Top_ctrl1,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_ctrl1_ptrs[] = 
{
    &internalports_Top_ctrl1[0],
    &internalports_Top_ctrl1[1]
};

static Capsule_Ctrl1 top_ctrl1( &Ctrl1, &Top_slots[InstId_Top_ctrl1], borderports_Top_ctrl1_ptrs, internalports_Top_ctrl1_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_ctrl2[] = 
{
    {
        0,
        &borderports_Top_mainCtrl[Capsule_MainCtrl::borderport_ctrl2]
    },
    {
        0,
        &borderports_Top_sensor2[Capsule_Sensor2::borderport_ctrl2]
    }
};

UMLRTCommsPort borderports_Top_ctrl2[] = 
{
    {
        &Ctrl2,
        Capsule_Ctrl2::borderport_main,
        &Top_slots[InstId_Top_ctrl2],
        1,
        borderfarEndList_Top_ctrl2,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Ctrl2,
        Capsule_Ctrl2::borderport_sensor2,
        &Top_slots[InstId_Top_ctrl2],
        1,
        &borderfarEndList_Top_ctrl2[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_ctrl2_ptrs[] = 
{
    &borderports_Top_ctrl2[0],
    &borderports_Top_ctrl2[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_ctrl2[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_ctrl2[] = 
{
    {
        &Ctrl2,
        Capsule_Ctrl2::internalport_timingC2,
        &Top_slots[InstId_Top_ctrl2],
        1,
        &internalfarEndList_Top_ctrl2[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &Ctrl2,
        Capsule_Ctrl2::internalport_log,
        &Top_slots[InstId_Top_ctrl2],
        1,
        internalfarEndList_Top_ctrl2,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_ctrl2_ptrs[] = 
{
    &internalports_Top_ctrl2[0],
    &internalports_Top_ctrl2[1]
};

static Capsule_Ctrl2 top_ctrl2( &Ctrl2, &Top_slots[InstId_Top_ctrl2], borderports_Top_ctrl2_ptrs, internalports_Top_ctrl2_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_mainCtrl[] = 
{
    {
        0,
        &borderports_Top_ctrl1[Capsule_Ctrl1::borderport_main]
    },
    {
        0,
        &borderports_Top_ctrl2[Capsule_Ctrl2::borderport_main]
    },
    {
        0,
        &borderports_Top_sensor1[Capsule_Sensor1::borderport_main]
    },
    {
        0,
        &borderports_Top_sensor2[Capsule_Sensor2::borderport_main]
    }
};

UMLRTCommsPort borderports_Top_mainCtrl[] = 
{
    {
        &MainCtrl,
        Capsule_MainCtrl::borderport_ctrl1,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        borderfarEndList_Top_mainCtrl,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &MainCtrl,
        Capsule_MainCtrl::borderport_ctrl2,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        &borderfarEndList_Top_mainCtrl[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &MainCtrl,
        Capsule_MainCtrl::borderport_sensor1,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        &borderfarEndList_Top_mainCtrl[2],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &MainCtrl,
        Capsule_MainCtrl::borderport_sensor2,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        &borderfarEndList_Top_mainCtrl[3],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_mainCtrl_ptrs[] = 
{
    &borderports_Top_mainCtrl[0],
    &borderports_Top_mainCtrl[1],
    &borderports_Top_mainCtrl[2],
    &borderports_Top_mainCtrl[3]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_mainCtrl[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_mainCtrl[] = 
{
    {
        &MainCtrl,
        Capsule_MainCtrl::internalport_timingM,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        &internalfarEndList_Top_mainCtrl[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &MainCtrl,
        Capsule_MainCtrl::internalport_log,
        &Top_slots[InstId_Top_mainCtrl],
        1,
        internalfarEndList_Top_mainCtrl,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_mainCtrl_ptrs[] = 
{
    &internalports_Top_mainCtrl[0],
    &internalports_Top_mainCtrl[1]
};

static Capsule_MainCtrl top_mainCtrl( &MainCtrl, &Top_slots[InstId_Top_mainCtrl], borderports_Top_mainCtrl_ptrs, internalports_Top_mainCtrl_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_sensor1[] = 
{
    {
        0,
        &borderports_Top_ctrl1[Capsule_Ctrl1::borderport_sensor1]
    },
    {
        0,
        &borderports_Top_mainCtrl[Capsule_MainCtrl::borderport_sensor1]
    }
};

UMLRTCommsPort borderports_Top_sensor1[] = 
{
    {
        &Sensor1,
        Capsule_Sensor1::borderport_ctrl1,
        &Top_slots[InstId_Top_sensor1],
        1,
        borderfarEndList_Top_sensor1,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Sensor1,
        Capsule_Sensor1::borderport_main,
        &Top_slots[InstId_Top_sensor1],
        1,
        &borderfarEndList_Top_sensor1[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_sensor1_ptrs[] = 
{
    &borderports_Top_sensor1[0],
    &borderports_Top_sensor1[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_sensor1[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_sensor1[] = 
{
    {
        &Sensor1,
        Capsule_Sensor1::internalport_timingS,
        &Top_slots[InstId_Top_sensor1],
        1,
        &internalfarEndList_Top_sensor1[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &Sensor1,
        Capsule_Sensor1::internalport_log,
        &Top_slots[InstId_Top_sensor1],
        1,
        internalfarEndList_Top_sensor1,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_sensor1_ptrs[] = 
{
    &internalports_Top_sensor1[0],
    &internalports_Top_sensor1[1]
};

static Capsule_Sensor1 top_sensor1( &Sensor1, &Top_slots[InstId_Top_sensor1], borderports_Top_sensor1_ptrs, internalports_Top_sensor1_ptrs, true );

static UMLRTCommsPortFarEnd borderfarEndList_Top_sensor2[] = 
{
    {
        0,
        &borderports_Top_ctrl2[Capsule_Ctrl2::borderport_sensor2]
    },
    {
        0,
        &borderports_Top_mainCtrl[Capsule_MainCtrl::borderport_sensor2]
    }
};

UMLRTCommsPort borderports_Top_sensor2[] = 
{
    {
        &Sensor2,
        Capsule_Sensor2::borderport_ctrl2,
        &Top_slots[InstId_Top_sensor2],
        1,
        borderfarEndList_Top_sensor2,
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        &Sensor2,
        Capsule_Sensor2::borderport_main,
        &Top_slots[InstId_Top_sensor2],
        1,
        &borderfarEndList_Top_sensor2[1],
        NULL,
        NULL,
        "",
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPort * borderports_Top_sensor2_ptrs[] = 
{
    &borderports_Top_sensor2[0],
    &borderports_Top_sensor2[1]
};

static UMLRTCommsPortFarEnd internalfarEndList_Top_sensor2[] = 
{
    {
        0,
        NULL
    },
    {
        0,
        NULL
    }
};

UMLRTCommsPort internalports_Top_sensor2[] = 
{
    {
        &Sensor2,
        Capsule_Sensor2::internalport_timingS2,
        &Top_slots[InstId_Top_sensor2],
        1,
        &internalfarEndList_Top_sensor2[1],
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    },
    {
        &Sensor2,
        Capsule_Sensor2::internalport_log,
        &Top_slots[InstId_Top_sensor2],
        1,
        internalfarEndList_Top_sensor2,
        NULL,
        NULL,
        "",
        true,
        false,
        true,
        false,
        false,
        false,
        false,
        true,
        false,
        false,
        false
    }
};

static const UMLRTCommsPort * internalports_Top_sensor2_ptrs[] = 
{
    &internalports_Top_sensor2[0],
    &internalports_Top_sensor2[1]
};

static Capsule_Sensor2 top_sensor2( &Sensor2, &Top_slots[InstId_Top_sensor2], borderports_Top_sensor2_ptrs, internalports_Top_sensor2_ptrs, true );

UMLRTSlot Top_slots[] = 
{
    {
        "Top",
        0,
        &Top,
        NULL,
        0,
        &top,
        &DefaultController_,
        5,
        parts_Top,
        0,
        NULL,
        NULL,
        true,
        false
    },
    {
        "Top.ctrl1",
        0,
        &Ctrl1,
        &Top,
        Capsule_Top::part_ctrl1,
        &top_ctrl1,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_ctrl1,
        NULL,
        true,
        false
    },
    {
        "Top.ctrl2",
        0,
        &Ctrl2,
        &Top,
        Capsule_Top::part_ctrl2,
        &top_ctrl2,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_ctrl2,
        NULL,
        true,
        false
    },
    {
        "Top.mainCtrl",
        0,
        &MainCtrl,
        &Top,
        Capsule_Top::part_mainCtrl,
        &top_mainCtrl,
        &DefaultController_,
        0,
        NULL,
        4,
        borderports_Top_mainCtrl,
        NULL,
        true,
        false
    },
    {
        "Top.sensor1",
        0,
        &Sensor1,
        &Top,
        Capsule_Top::part_sensor1,
        &top_sensor1,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_sensor1,
        NULL,
        true,
        false
    },
    {
        "Top.sensor2",
        0,
        &Sensor2,
        &Top,
        Capsule_Top::part_sensor2,
        &top_sensor2,
        &DefaultController_,
        0,
        NULL,
        2,
        borderports_Top_sensor2,
        NULL,
        true,
        false
    }
};

