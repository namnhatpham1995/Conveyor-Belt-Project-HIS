
#ifndef MAINCTRL_HH
#define MAINCTRL_HH

#include "ClientMain.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_MainCtrl : public UMLRTCapsule
{
public:
    Capsule_MainCtrl( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    ClientMain::Conj ctrl1;
public:
    enum BorderPortId
    {
        borderport_ctrl1,
        borderport_ctrl2,
        borderport_sensor1,
        borderport_sensor2
    };
protected:
    ClientMain::Conj ctrl2;
    UMLRTLogProtocol_baserole log;
    ClientMain::Conj sensor1;
    ClientMain::Conj sensor2;
    UMLRTTimerProtocol_baserole timingM;
public:
    enum InternalPortId
    {
        internalport_timingM,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_ctrl1,
        port_ctrl2,
        port_log,
        port_sensor1,
        port_sensor2,
        port_timingM
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    bool chooseS2;
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        Working,
        Working__Countdown1,
        Working__Countdown2,
        Working__Make1requestAgain,
        Working__Make2RequestAgain,
        Working__WaitS,
        Working__boundary,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[9];
    State currentState;
    State history[1];
    void save_history( State compositeState, State subState );
    bool check_history( State compositeState, State subState );
    void update_state( State newState );
    void transitionaction_____Working__request1( const UMLRTMessage * msg );
    void transitionaction_____Working__request2( const UMLRTMessage * msg );
    void transitionaction_____Working__timeout12( const UMLRTMessage * msg );
    void transitionaction_____Working__timeout21( const UMLRTMessage * msg );
    void transitionaction_____Working__transition0( const UMLRTMessage * msg );
    void transitionaction_____Working__transition10( const UMLRTMessage * msg );
    void transitionaction_____Working__transition11( const UMLRTMessage * msg );
    bool guard_____Working__transition11( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_1( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_2( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_3( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_4( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_5( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_6_to_unvisited_boundary( const UMLRTMessage * msg );
    void actionchain_____Working__new_transition_7_to_visited_boundary( const UMLRTMessage * msg );
    void actionchain_____Working__request1( const UMLRTMessage * msg );
    void actionchain_____Working__request2( const UMLRTMessage * msg );
    void actionchain_____Working__timeout1( const UMLRTMessage * msg );
    void actionchain_____Working__timeout12( const UMLRTMessage * msg );
    void actionchain_____Working__timeout2( const UMLRTMessage * msg );
    void actionchain_____Working__timeout21( const UMLRTMessage * msg );
    void actionchain_____Working__transition0( const UMLRTMessage * msg );
    void actionchain_____Working__transition10( const UMLRTMessage * msg );
    void actionchain_____Working__transition11( const UMLRTMessage * msg );
    void actionchain_____Working__transition9( const UMLRTMessage * msg );
    void actionchain_____Working__waitingRequest1( const UMLRTMessage * msg );
    void actionchain_____Working__waitingRequest2( const UMLRTMessage * msg );
    State junction_____Working__connectionPoint0( const UMLRTMessage * msg );
    State choice_____Working__deephistory( const UMLRTMessage * msg );
    State choice_____Working__subvertex5( const UMLRTMessage * msg );
    State state_____Working__Countdown1( const UMLRTMessage * msg );
    State state_____Working__Countdown2( const UMLRTMessage * msg );
    State state_____Working__Make1requestAgain( const UMLRTMessage * msg );
    State state_____Working__Make2RequestAgain( const UMLRTMessage * msg );
    State state_____Working__WaitS( const UMLRTMessage * msg );
    State state_____Working__boundary( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass MainCtrl;

#endif

