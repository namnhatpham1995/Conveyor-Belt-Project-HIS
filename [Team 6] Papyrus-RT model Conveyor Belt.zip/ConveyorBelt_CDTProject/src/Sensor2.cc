
#include "Sensor2.hh"

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Sensor2::Capsule_Sensor2( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, ctrl2( borderPorts[borderport_ctrl2] )
, main( borderPorts[borderport_main] )
, timingS2( internalPorts[internalport_timingS2] )
, hitCount2( 1 )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[WorkingS2] = "WorkingS2";
    stateNames[WorkingS2__WaitCtrl2] = "WorkingS2__WaitCtrl2";
    stateNames[WorkingS2__WaitPackage2] = "WorkingS2__WaitPackage2";
    stateNames[WorkingS2__boundary] = "WorkingS2__boundary";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
    int i = 0;
    while( i < 1 )
        history[i++] = SPECIAL_INTERNAL_STATE_UNVISITED;
}









void Capsule_Sensor2::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl2, index, true );
            break;
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, true );
            break;
        }
}

void Capsule_Sensor2::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl2, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_ctrl2], index );
            break;
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_main], index );
            break;
        }
}






void Capsule_Sensor2::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case WorkingS2__WaitPackage2:
        currentState = state_____WorkingS2__WaitPackage2( &message );
        break;
    case WorkingS2__WaitCtrl2:
        currentState = state_____WorkingS2__WaitCtrl2( &message );
        break;
    case WorkingS2__boundary:
        currentState = state_____WorkingS2__boundary( &message );
        break;
    default:
        break;
    }
}

void Capsule_Sensor2::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = junction_____WorkingS2__connectionPoint0( &message );
}

const char * Capsule_Sensor2::getCurrentStateString() const
{
    return stateNames[currentState];
}





void Capsule_Sensor2::save_history( Capsule_Sensor2::State compositeState, Capsule_Sensor2::State subState )
{
    history[compositeState] = subState;
}

bool Capsule_Sensor2::check_history( Capsule_Sensor2::State compositeState, Capsule_Sensor2::State subState )
{
    return history[compositeState] == subState;
}

void Capsule_Sensor2::update_state( Capsule_Sensor2::State newState )
{
    currentState = newState;
}

void Capsule_Sensor2::entryaction_____WorkingS2( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 entry  */
    //UMLRTTimespec::getclock(&begin2);
    //log.show("Line 2: Package at ");
    //log.log(begin2.tv_sec-line2.tv_sec);
    //package2sm.ping2().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__receiveConfirm( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::WaitCtrl2,WorkingS2::subvertex2,confirm:ctrl2 */
    UMLRTTimespec::getclock(&end2);
    log.show("Line 2 load successfully at ");
    log.log(end2.tv_sec-line2.tv_sec);
    log.show("Line 2 load successfully after: ");
    log.log(end2.tv_sec-begin2.tv_sec);
    log.log(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__requestAgain( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::WaitCtrl2,WorkingS2::WaitCtrl2,reply:main */
    log.log("Line 2: request again!");
    main.request().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__transition0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::connectionPoint0,WorkingS2::WaitPackage2 */
    UMLRTTimespec::getclock(&line2);
    log.log("Starting sensor 2 at ");
    log.log(line2.tv_sec-line2.tv_sec);
    timingS2.informIn(UMLRTTimespec((rand()%3)+1, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__transition1( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::WaitPackage2,WorkingS2::WaitCtrl2,timeout:timingS2 */
    UMLRTTimespec::getclock(&begin2);
    log.show("Line 2: Package "); log.show(hitCount2); log.show(" at: ");
    log.log(begin2.tv_sec-line2.tv_sec);
    main.request().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__transition4( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::subvertex2,WorkingS2::WaitPackage2 */
    timingS2.informIn(UMLRTTimespec((rand()%7)+1, 0));
    hitCount2++;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::transitionaction_____WorkingS2__transition5( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 transition WorkingS2::subvertex2,WorkingS2 */
    UMLRTTimespec::getclock(&line2end);
    log.show( "Line 2 ends after ");
    log.log(line2end.tv_sec-line2.tv_sec);
    log.log( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

bool Capsule_Sensor2::guard_____WorkingS2__transition4( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Sensor2::WorkingS2 guard WorkingS2::subvertex2,WorkingS2::WaitPackage2 */
    return hitCount2 <5;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Sensor2::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( WorkingS2 );
    entryaction_____WorkingS2( msg );
}

void Capsule_Sensor2::actionchain_____WorkingS2__new_transition_1( const UMLRTMessage * msg )
{
    update_state( WorkingS2__WaitPackage2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__new_transition_2( const UMLRTMessage * msg )
{
    update_state( WorkingS2__WaitCtrl2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingS2__boundary );
}

void Capsule_Sensor2::actionchain_____WorkingS2__new_transition_4_to_visited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingS2__boundary );
}

void Capsule_Sensor2::actionchain_____WorkingS2__receiveConfirm( const UMLRTMessage * msg )
{
    update_state( WorkingS2 );
    transitionaction_____WorkingS2__receiveConfirm( msg );
}

void Capsule_Sensor2::actionchain_____WorkingS2__requestAgain( const UMLRTMessage * msg )
{
    update_state( WorkingS2 );
    transitionaction_____WorkingS2__requestAgain( msg );
    update_state( WorkingS2__WaitCtrl2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__transition0( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS2__transition0( msg );
    update_state( WorkingS2__WaitPackage2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__transition1( const UMLRTMessage * msg )
{
    update_state( WorkingS2 );
    transitionaction_____WorkingS2__transition1( msg );
    update_state( WorkingS2__WaitCtrl2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__transition4( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS2__transition4( msg );
    update_state( WorkingS2__WaitPackage2 );
}

void Capsule_Sensor2::actionchain_____WorkingS2__transition5( const UMLRTMessage * msg )
{
    transitionaction_____WorkingS2__transition5( msg );
}

Capsule_Sensor2::State Capsule_Sensor2::junction_____WorkingS2__connectionPoint0( const UMLRTMessage * msg )
{
    actionchain_____WorkingS2__transition0( msg );
    return WorkingS2__WaitPackage2;
}

Capsule_Sensor2::State Capsule_Sensor2::choice_____WorkingS2__deephistory( const UMLRTMessage * msg )
{
    if( check_history( WorkingS2, WorkingS2__WaitPackage2 ) )
    {
        actionchain_____WorkingS2__new_transition_1( msg );
        return WorkingS2__WaitPackage2;
    }
    else if( check_history( WorkingS2, WorkingS2__WaitCtrl2 ) )
    {
        actionchain_____WorkingS2__new_transition_2( msg );
        return WorkingS2__WaitCtrl2;
    }
    else if( check_history( WorkingS2, SPECIAL_INTERNAL_STATE_UNVISITED ) )
    {
        actionchain_____WorkingS2__new_transition_3_to_unvisited_boundary( msg );
        return WorkingS2__boundary;
    }
    else if( check_history( WorkingS2, WorkingS2__boundary ) )
    {
        actionchain_____WorkingS2__new_transition_4_to_visited_boundary( msg );
        return WorkingS2__boundary;
    }
    return currentState;
}

Capsule_Sensor2::State Capsule_Sensor2::choice_____WorkingS2__subvertex2( const UMLRTMessage * msg )
{
    if( guard_____WorkingS2__transition4( msg ) )
    {
        actionchain_____WorkingS2__transition4( msg );
        return WorkingS2__WaitPackage2;
    }
    else
    {
        actionchain_____WorkingS2__transition5( msg );
        return choice_____WorkingS2__deephistory( msg );
    }
    return currentState;
}

Capsule_Sensor2::State Capsule_Sensor2::state_____WorkingS2__WaitCtrl2( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_ctrl2:
        switch( msg->getSignalId() )
        {
        case ClientClient::signal_confirm:
            actionchain_____WorkingS2__receiveConfirm( msg );
            return choice_____WorkingS2__subvertex2( msg );
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    case port_main:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_reply:
            actionchain_____WorkingS2__requestAgain( msg );
            return WorkingS2__WaitCtrl2;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor2::State Capsule_Sensor2::state_____WorkingS2__WaitPackage2( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingS2:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____WorkingS2__transition1( msg );
            return WorkingS2__WaitCtrl2;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Sensor2::State Capsule_Sensor2::state_____WorkingS2__boundary( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Sensor2::port_ctrl2,
        "ClientClient",
        "ctrl2",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Sensor2::port_main,
        "ClientMain",
        "main",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Sensor2::port_timingS2,
        "Timing",
        "timingS2",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_Sensor2::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Sensor2( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Sensor2 );
    slot->capsule = new Capsule_Sensor2( &Sensor2, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Sensor2 = 
{
    "Sensor2",
    NULL,
    instantiate_Sensor2,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

