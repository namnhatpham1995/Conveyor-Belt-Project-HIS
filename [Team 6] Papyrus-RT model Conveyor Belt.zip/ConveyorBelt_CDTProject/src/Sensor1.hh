
#ifndef SENSOR1_HH
#define SENSOR1_HH

#include "ClientClient.hh"
#include "ClientMain.hh"
#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtlogprotocol.hh"
#include "umlrtmessage.hh"
#include "umlrttimerprotocol.hh"
#include "umlrttimespec.hh"
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Sensor1 : public UMLRTCapsule
{
public:
    Capsule_Sensor1( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
protected:
    ClientClient::Base ctrl1;
public:
    enum BorderPortId
    {
        borderport_ctrl1,
        borderport_main
    };
protected:
    UMLRTLogProtocol_baserole log;
    ClientMain::Base main;
    UMLRTTimerProtocol_baserole timingS;
public:
    enum InternalPortId
    {
        internalport_timingS,
        internalport_log
    };
    enum PartId
    {
    };
    enum PortId
    {
        port_ctrl1,
        port_log,
        port_main,
        port_timingS
    };
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    int hitCount;
    UMLRTTimespec begin1;
    UMLRTTimespec line1;
    UMLRTTimespec end1;
    UMLRTTimespec line1end;
    virtual void inject( const UMLRTMessage & message );
    virtual void initialize( const UMLRTMessage & message );
    const char * getCurrentStateString() const;
private:
    enum State
    {
        WorkingS1,
        WorkingS1__WaitCtrl,
        WorkingS1__WaitPackage,
        WorkingS1__boundary,
        SPECIAL_INTERNAL_STATE_TOP,
        SPECIAL_INTERNAL_STATE_UNVISITED
    };
    const char * stateNames[6];
    State currentState;
    State history[1];
    void save_history( State compositeState, State subState );
    bool check_history( State compositeState, State subState );
    void update_state( State newState );
    void transitionaction_____WorkingS1__receiveConfirm( const UMLRTMessage * msg );
    void transitionaction_____WorkingS1__requestAgain( const UMLRTMessage * msg );
    void transitionaction_____WorkingS1__transition0( const UMLRTMessage * msg );
    void transitionaction_____WorkingS1__transition1( const UMLRTMessage * msg );
    void transitionaction_____WorkingS1__transition4( const UMLRTMessage * msg );
    void transitionaction_____WorkingS1__transition5( const UMLRTMessage * msg );
    bool guard_____WorkingS1__transition4( const UMLRTMessage * msg );
    void actionchain_____Initial( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__new_transition_1( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__new_transition_2( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__new_transition_4_to_visited_boundary( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__receiveConfirm( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__requestAgain( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__transition0( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__transition1( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__transition4( const UMLRTMessage * msg );
    void actionchain_____WorkingS1__transition5( const UMLRTMessage * msg );
    State junction_____WorkingS1__connectionPoint0( const UMLRTMessage * msg );
    State choice_____WorkingS1__deephistory( const UMLRTMessage * msg );
    State choice_____WorkingS1__subvertex2( const UMLRTMessage * msg );
    State state_____WorkingS1__WaitCtrl( const UMLRTMessage * msg );
    State state_____WorkingS1__WaitPackage( const UMLRTMessage * msg );
    State state_____WorkingS1__boundary( const UMLRTMessage * msg );
};
extern const UMLRTCapsuleClass Sensor1;

#endif

