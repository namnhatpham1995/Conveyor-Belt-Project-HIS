
#include "ClientMain.hh"

#include "umlrtinsignal.hh"
#include "umlrtobjectclass.hh"
#include "umlrtoutsignal.hh"
struct UMLRTCommsPort;

static UMLRTObject_field fields_reply[] = 
{
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    {
        0,
        0,
        0,
        0,
        0
    }
    #endif
};

static UMLRTObject payload_reply = 
{
    0,
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    1
    #else
    0
    #endif
    ,
    fields_reply
};

static UMLRTObject_field fields_request[] = 
{
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    {
        0,
        0,
        0,
        0,
        0
    }
    #endif
};

static UMLRTObject payload_request = 
{
    0,
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    1
    #else
    0
    #endif
    ,
    fields_request
};

ClientMain::Base::Base( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTInSignal ClientMain::Base::reply() const
{
    UMLRTInSignal signal;
    signal.initialize( "reply", signal_reply, srcPort, &payload_reply );
    return signal;
}

UMLRTOutSignal ClientMain::Base::request() const
{
    UMLRTOutSignal signal;
    signal.initialize( "request", signal_request, srcPort, &payload_request );
    return signal;
}

ClientMain::Conj::Conj( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTOutSignal ClientMain::Conj::reply() const
{
    UMLRTOutSignal signal;
    signal.initialize( "reply", signal_reply, srcPort, &payload_reply );
    return signal;
}

UMLRTInSignal ClientMain::Conj::request() const
{
    UMLRTInSignal signal;
    signal.initialize( "request", signal_request, srcPort, &payload_request );
    return signal;
}


