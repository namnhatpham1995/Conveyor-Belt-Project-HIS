
#include "Ctrl1.hh"

#include "ClientMain.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Ctrl1::Capsule_Ctrl1( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, main( borderPorts[borderport_main] )
, sensor1( borderPorts[borderport_sensor1] )
, timingC1( internalPorts[internalport_timingC1] )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[WorkingC1] = "WorkingC1";
    stateNames[WorkingC1__Countdown] = "WorkingC1__Countdown";
    stateNames[WorkingC1__WaitM] = "WorkingC1__WaitM";
    stateNames[WorkingC1__boundary] = "WorkingC1__boundary";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
    int i = 0;
    while( i < 1 )
        history[i++] = SPECIAL_INTERNAL_STATE_UNVISITED;
}









void Capsule_Ctrl1::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, true );
            break;
        case borderport_sensor1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor1, index, true );
            break;
        }
}

void Capsule_Ctrl1::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_main], index );
            break;
        case borderport_sensor1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor1, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_sensor1], index );
            break;
        }
}

void Capsule_Ctrl1::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case WorkingC1__WaitM:
        currentState = state_____WorkingC1__WaitM( &message );
        break;
    case WorkingC1__Countdown:
        currentState = state_____WorkingC1__Countdown( &message );
        break;
    case WorkingC1__boundary:
        currentState = state_____WorkingC1__boundary( &message );
        break;
    default:
        break;
    }
}

void Capsule_Ctrl1::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = junction_____WorkingC1__connectionPoint0( &message );
}

const char * Capsule_Ctrl1::getCurrentStateString() const
{
    return stateNames[currentState];
}





void Capsule_Ctrl1::save_history( Capsule_Ctrl1::State compositeState, Capsule_Ctrl1::State subState )
{
    history[compositeState] = subState;
}

bool Capsule_Ctrl1::check_history( Capsule_Ctrl1::State compositeState, Capsule_Ctrl1::State subState )
{
    return history[compositeState] == subState;
}

void Capsule_Ctrl1::update_state( Capsule_Ctrl1::State newState )
{
    currentState = newState;
}

void Capsule_Ctrl1::transitionaction_____WorkingC1__startCtrl( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl1::WorkingC1 transition WorkingC1::WaitM,WorkingC1::Countdown,reply:main */
    log.log("Line 1 waits for loading slot");
    timingC1.informIn(UMLRTTimespec(5, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl1::transitionaction_____WorkingC1__transition0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl1::WorkingC1 transition WorkingC1::connectionPoint0,WorkingC1::WaitM */
    log.log("Starting controller 1");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl1::transitionaction_____WorkingC1__transition2( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl1::WorkingC1 transition WorkingC1::Countdown,WorkingC1::WaitM,timeout:timingC1 */
    sensor1.confirm().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl1::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( WorkingC1 );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__new_transition_1( const UMLRTMessage * msg )
{
    update_state( WorkingC1__WaitM );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__new_transition_2( const UMLRTMessage * msg )
{
    update_state( WorkingC1__Countdown );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingC1__boundary );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__new_transition_4_to_visited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingC1__boundary );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__startCtrl( const UMLRTMessage * msg )
{
    update_state( WorkingC1 );
    transitionaction_____WorkingC1__startCtrl( msg );
    update_state( WorkingC1__Countdown );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__transition0( const UMLRTMessage * msg )
{
    transitionaction_____WorkingC1__transition0( msg );
    update_state( WorkingC1__WaitM );
}

void Capsule_Ctrl1::actionchain_____WorkingC1__transition2( const UMLRTMessage * msg )
{
    update_state( WorkingC1 );
    transitionaction_____WorkingC1__transition2( msg );
    update_state( WorkingC1__WaitM );
}

Capsule_Ctrl1::State Capsule_Ctrl1::junction_____WorkingC1__connectionPoint0( const UMLRTMessage * msg )
{
    actionchain_____WorkingC1__transition0( msg );
    return WorkingC1__WaitM;
}

Capsule_Ctrl1::State Capsule_Ctrl1::choice_____WorkingC1__deephistory( const UMLRTMessage * msg )
{
    if( check_history( WorkingC1, WorkingC1__WaitM ) )
    {
        actionchain_____WorkingC1__new_transition_1( msg );
        return WorkingC1__WaitM;
    }
    else if( check_history( WorkingC1, WorkingC1__Countdown ) )
    {
        actionchain_____WorkingC1__new_transition_2( msg );
        return WorkingC1__Countdown;
    }
    else if( check_history( WorkingC1, SPECIAL_INTERNAL_STATE_UNVISITED ) )
    {
        actionchain_____WorkingC1__new_transition_3_to_unvisited_boundary( msg );
        return WorkingC1__boundary;
    }
    else if( check_history( WorkingC1, WorkingC1__boundary ) )
    {
        actionchain_____WorkingC1__new_transition_4_to_visited_boundary( msg );
        return WorkingC1__boundary;
    }
    return currentState;
}

Capsule_Ctrl1::State Capsule_Ctrl1::state_____WorkingC1__Countdown( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingC1:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____WorkingC1__transition2( msg );
            return WorkingC1__WaitM;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Ctrl1::State Capsule_Ctrl1::state_____WorkingC1__WaitM( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_main:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_reply:
            actionchain_____WorkingC1__startCtrl( msg );
            return WorkingC1__Countdown;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Ctrl1::State Capsule_Ctrl1::state_____WorkingC1__boundary( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Ctrl1::port_main,
        "ClientMain",
        "main",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Ctrl1::port_sensor1,
        "ClientClient",
        "sensor1",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Ctrl1::port_timingC1,
        "Timing",
        "timingC1",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_Ctrl1::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Ctrl1( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Ctrl1 );
    slot->capsule = new Capsule_Ctrl1( &Ctrl1, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Ctrl1 = 
{
    "Ctrl1",
    NULL,
    instantiate_Ctrl1,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

