
#include "ClientClient.hh"

#include "umlrtinsignal.hh"
#include "umlrtobjectclass.hh"
#include "umlrtoutsignal.hh"
struct UMLRTCommsPort;

static UMLRTObject_field fields_confirm[] = 
{
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    {
        0,
        0,
        0,
        0,
        0
    }
    #endif
};

static UMLRTObject payload_confirm = 
{
    0,
    #ifdef NEED_NON_FLEXIBLE_ARRAY
    1
    #else
    0
    #endif
    ,
    fields_confirm
};

ClientClient::Base::Base( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTInSignal ClientClient::Base::confirm() const
{
    UMLRTInSignal signal;
    signal.initialize( "confirm", signal_confirm, srcPort, &payload_confirm );
    return signal;
}

ClientClient::Conj::Conj( const UMLRTCommsPort * & srcPort )
: UMLRTProtocol( srcPort )
{
}

UMLRTOutSignal ClientClient::Conj::confirm() const
{
    UMLRTOutSignal signal;
    signal.initialize( "confirm", signal_confirm, srcPort, &payload_confirm );
    return signal;
}


