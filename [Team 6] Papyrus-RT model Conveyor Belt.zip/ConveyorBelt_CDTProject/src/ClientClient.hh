
#ifndef CLIENTCLIENT_HH
#define CLIENTCLIENT_HH

#include "umlrtinsignal.hh"
#include "umlrtoutsignal.hh"
#include "umlrtprotocol.hh"
#include "umlrtsignal.hh"
struct UMLRTCommsPort;

namespace ClientClient
{
    class Base : public UMLRTProtocol
    {
    public:
        Base( const UMLRTCommsPort * & srcPort );
        UMLRTInSignal confirm() const;
    };
    enum SignalId
    {
        signal_confirm = UMLRTSignal::FIRST_PROTOCOL_SIGNAL_ID
    };
    class Conj : public UMLRTProtocol
    {
    public:
        Conj( const UMLRTCommsPort * & srcPort );
        UMLRTOutSignal confirm() const;
    };
};

#endif

