
#ifndef CLIENTMAIN_HH
#define CLIENTMAIN_HH

#include "umlrtinsignal.hh"
#include "umlrtoutsignal.hh"
#include "umlrtprotocol.hh"
#include "umlrtsignal.hh"
struct UMLRTCommsPort;

namespace ClientMain
{
    class Base : public UMLRTProtocol
    {
    public:
        Base( const UMLRTCommsPort * & srcPort );
        UMLRTInSignal reply() const;
        UMLRTOutSignal request() const;
    };
    class Conj : public UMLRTProtocol
    {
    public:
        Conj( const UMLRTCommsPort * & srcPort );
        UMLRTOutSignal reply() const;
        UMLRTInSignal request() const;
    };
    enum SignalId
    {
        signal_reply = UMLRTSignal::FIRST_PROTOCOL_SIGNAL_ID,
        signal_request
    };
};

#endif

