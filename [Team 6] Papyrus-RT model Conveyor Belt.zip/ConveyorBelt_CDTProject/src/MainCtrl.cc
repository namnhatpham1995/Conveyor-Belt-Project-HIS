
#include "MainCtrl.hh"

#include "ClientMain.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_MainCtrl::Capsule_MainCtrl( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, ctrl1( borderPorts[borderport_ctrl1] )
, ctrl2( borderPorts[borderport_ctrl2] )
, sensor1( borderPorts[borderport_sensor1] )
, sensor2( borderPorts[borderport_sensor2] )
, timingM( internalPorts[internalport_timingM] )
, chooseS2( true )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[Working] = "Working";
    stateNames[Working__Countdown1] = "Working__Countdown1";
    stateNames[Working__Countdown2] = "Working__Countdown2";
    stateNames[Working__Make1requestAgain] = "Working__Make1requestAgain";
    stateNames[Working__Make2RequestAgain] = "Working__Make2RequestAgain";
    stateNames[Working__WaitS] = "Working__WaitS";
    stateNames[Working__boundary] = "Working__boundary";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
    int i = 0;
    while( i < 1 )
        history[i++] = SPECIAL_INTERNAL_STATE_UNVISITED;
}











void Capsule_MainCtrl::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl1, index, true );
            break;
        case borderport_ctrl2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl2, index, true );
            break;
        case borderport_sensor1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor1, index, true );
            break;
        case borderport_sensor2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor2, index, true );
            break;
        }
}

void Capsule_MainCtrl::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_ctrl1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl1, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_ctrl1], index );
            break;
        case borderport_ctrl2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_ctrl2, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_ctrl2], index );
            break;
        case borderport_sensor1:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor1, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_sensor1], index );
            break;
        case borderport_sensor2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor2, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_sensor2], index );
            break;
        }
}


void Capsule_MainCtrl::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case Working__WaitS:
        currentState = state_____Working__WaitS( &message );
        break;
    case Working__Countdown1:
        currentState = state_____Working__Countdown1( &message );
        break;
    case Working__Countdown2:
        currentState = state_____Working__Countdown2( &message );
        break;
    case Working__Make1requestAgain:
        currentState = state_____Working__Make1requestAgain( &message );
        break;
    case Working__Make2RequestAgain:
        currentState = state_____Working__Make2RequestAgain( &message );
        break;
    case Working__boundary:
        currentState = state_____Working__boundary( &message );
        break;
    default:
        break;
    }
}

void Capsule_MainCtrl::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = junction_____Working__connectionPoint0( &message );
}

const char * Capsule_MainCtrl::getCurrentStateString() const
{
    return stateNames[currentState];
}





void Capsule_MainCtrl::save_history( Capsule_MainCtrl::State compositeState, Capsule_MainCtrl::State subState )
{
    history[compositeState] = subState;
}

bool Capsule_MainCtrl::check_history( Capsule_MainCtrl::State compositeState, Capsule_MainCtrl::State subState )
{
    return history[compositeState] == subState;
}

void Capsule_MainCtrl::update_state( Capsule_MainCtrl::State newState )
{
    currentState = newState;
}

void Capsule_MainCtrl::transitionaction_____Working__request1( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::WaitS,Working::Countdown1,request:sensor1 */
    ctrl1.reply().send();
    timingM.informIn(UMLRTTimespec(5, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__request2( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::WaitS,Working::Countdown2,request:sensor2 */
    ctrl2.reply().send();
    timingM.informIn(UMLRTTimespec(5, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__timeout12( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::Make2RequestAgain,Working::WaitS,timeout:timingM */
    sensor2.reply().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__timeout21( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::Make1requestAgain,Working::WaitS,timeout:timingM */
    sensor1.reply().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__transition0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::connectionPoint0,Working::WaitS */
    log.log("Starting Main");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__transition10( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::subvertex5,Working::Make2RequestAgain */
    ctrl1.reply().send();
    timingM.informIn(UMLRTTimespec(5, 0)); 
    chooseS2=!chooseS2;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::transitionaction_____Working__transition11( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working transition Working::subvertex5,Working::Make1requestAgain */
    ctrl2.reply().send();
    timingM.informIn(UMLRTTimespec(5, 0)); 
    chooseS2=!chooseS2;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

bool Capsule_MainCtrl::guard_____Working__transition11( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::MainCtrl::Working guard Working::subvertex5,Working::Make1requestAgain */
    return chooseS2;
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_MainCtrl::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( Working );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_1( const UMLRTMessage * msg )
{
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_2( const UMLRTMessage * msg )
{
    update_state( Working__Countdown1 );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_3( const UMLRTMessage * msg )
{
    update_state( Working__Countdown2 );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_4( const UMLRTMessage * msg )
{
    update_state( Working__Make1requestAgain );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_5( const UMLRTMessage * msg )
{
    update_state( Working__Make2RequestAgain );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_6_to_unvisited_boundary( const UMLRTMessage * msg )
{
    update_state( Working__boundary );
}

void Capsule_MainCtrl::actionchain_____Working__new_transition_7_to_visited_boundary( const UMLRTMessage * msg )
{
    update_state( Working__boundary );
}

void Capsule_MainCtrl::actionchain_____Working__request1( const UMLRTMessage * msg )
{
    update_state( Working );
    transitionaction_____Working__request1( msg );
    update_state( Working__Countdown1 );
}

void Capsule_MainCtrl::actionchain_____Working__request2( const UMLRTMessage * msg )
{
    update_state( Working );
    transitionaction_____Working__request2( msg );
    update_state( Working__Countdown2 );
}

void Capsule_MainCtrl::actionchain_____Working__timeout1( const UMLRTMessage * msg )
{
    update_state( Working );
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__timeout12( const UMLRTMessage * msg )
{
    update_state( Working );
    transitionaction_____Working__timeout12( msg );
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__timeout2( const UMLRTMessage * msg )
{
    update_state( Working );
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__timeout21( const UMLRTMessage * msg )
{
    update_state( Working );
    transitionaction_____Working__timeout21( msg );
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__transition0( const UMLRTMessage * msg )
{
    transitionaction_____Working__transition0( msg );
    update_state( Working__WaitS );
}

void Capsule_MainCtrl::actionchain_____Working__transition10( const UMLRTMessage * msg )
{
    transitionaction_____Working__transition10( msg );
    update_state( Working__Make2RequestAgain );
}

void Capsule_MainCtrl::actionchain_____Working__transition11( const UMLRTMessage * msg )
{
    transitionaction_____Working__transition11( msg );
    update_state( Working__Make1requestAgain );
}

void Capsule_MainCtrl::actionchain_____Working__transition9( const UMLRTMessage * msg )
{
    update_state( Working );
}

void Capsule_MainCtrl::actionchain_____Working__waitingRequest1( const UMLRTMessage * msg )
{
    update_state( Working );
    update_state( Working__Make1requestAgain );
}

void Capsule_MainCtrl::actionchain_____Working__waitingRequest2( const UMLRTMessage * msg )
{
    update_state( Working );
    update_state( Working__Make2RequestAgain );
}

Capsule_MainCtrl::State Capsule_MainCtrl::junction_____Working__connectionPoint0( const UMLRTMessage * msg )
{
    actionchain_____Working__transition0( msg );
    return Working__WaitS;
}

Capsule_MainCtrl::State Capsule_MainCtrl::choice_____Working__deephistory( const UMLRTMessage * msg )
{
    if( check_history( Working, Working__WaitS ) )
    {
        actionchain_____Working__new_transition_1( msg );
        return Working__WaitS;
    }
    else if( check_history( Working, Working__Countdown1 ) )
    {
        actionchain_____Working__new_transition_2( msg );
        return Working__Countdown1;
    }
    else if( check_history( Working, Working__Countdown2 ) )
    {
        actionchain_____Working__new_transition_3( msg );
        return Working__Countdown2;
    }
    else if( check_history( Working, Working__Make1requestAgain ) )
    {
        actionchain_____Working__new_transition_4( msg );
        return Working__Make1requestAgain;
    }
    else if( check_history( Working, Working__Make2RequestAgain ) )
    {
        actionchain_____Working__new_transition_5( msg );
        return Working__Make2RequestAgain;
    }
    else if( check_history( Working, SPECIAL_INTERNAL_STATE_UNVISITED ) )
    {
        actionchain_____Working__new_transition_6_to_unvisited_boundary( msg );
        return Working__boundary;
    }
    else if( check_history( Working, Working__boundary ) )
    {
        actionchain_____Working__new_transition_7_to_visited_boundary( msg );
        return Working__boundary;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::choice_____Working__subvertex5( const UMLRTMessage * msg )
{
    if( guard_____Working__transition11( msg ) )
    {
        actionchain_____Working__transition11( msg );
        return Working__Make1requestAgain;
    }
    else
    {
        actionchain_____Working__transition10( msg );
        return Working__Make2RequestAgain;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__Countdown1( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingM:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____Working__timeout1( msg );
            return Working__WaitS;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    case port_sensor2:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_request:
            actionchain_____Working__waitingRequest2( msg );
            return Working__Make2RequestAgain;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__Countdown2( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingM:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____Working__timeout2( msg );
            return Working__WaitS;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    case port_sensor1:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_request:
            actionchain_____Working__waitingRequest1( msg );
            return Working__Make1requestAgain;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__Make1requestAgain( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingM:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____Working__timeout21( msg );
            return Working__WaitS;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__Make2RequestAgain( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingM:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____Working__timeout12( msg );
            return Working__WaitS;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__WaitS( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_sensor2:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_request:
            actionchain_____Working__request2( msg );
            return Working__Countdown2;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    case port_sensor1:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_request:
            actionchain_____Working__request1( msg );
            return Working__Countdown1;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_MainCtrl::State Capsule_MainCtrl::state_____Working__boundary( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_MainCtrl::port_ctrl1,
        "ClientMain",
        "ctrl1",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_MainCtrl::port_ctrl2,
        "ClientMain",
        "ctrl2",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_MainCtrl::port_sensor1,
        "ClientMain",
        "sensor1",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_MainCtrl::port_sensor2,
        "ClientMain",
        "sensor2",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_MainCtrl::port_timingM,
        "Timing",
        "timingM",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_MainCtrl::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_MainCtrl( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &MainCtrl );
    slot->capsule = new Capsule_MainCtrl( &MainCtrl, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass MainCtrl = 
{
    "MainCtrl",
    NULL,
    instantiate_MainCtrl,
    0,
    NULL,
    4,
    portroles_border,
    2,
    portroles_internal
};

