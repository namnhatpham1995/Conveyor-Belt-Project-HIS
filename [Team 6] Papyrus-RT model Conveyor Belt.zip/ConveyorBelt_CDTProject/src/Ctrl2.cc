
#include "Ctrl2.hh"

#include "ClientMain.hh"
#include "umlrtcommsportrole.hh"
#include "umlrtmessage.hh"
#include "umlrtslot.hh"
#include "umlrttimerprotocol.hh"
#include <cstddef>
#include "umlrtcapsuleclass.hh"
#include "umlrtframeservice.hh"
class UMLRTRtsInterface;
struct UMLRTCommsPort;

Capsule_Ctrl2::Capsule_Ctrl2( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat )
: UMLRTCapsule( NULL, cd, st, border, internal, isStat )
, main( borderPorts[borderport_main] )
, sensor2( borderPorts[borderport_sensor2] )
, timingC2( internalPorts[internalport_timingC2] )
, currentState( SPECIAL_INTERNAL_STATE_UNVISITED )
{
    stateNames[WorkingC2] = "WorkingC2";
    stateNames[WorkingC2__Countdown] = "WorkingC2__Countdown";
    stateNames[WorkingC2__WaitM] = "WorkingC2__WaitM";
    stateNames[WorkingC2__boundary] = "WorkingC2__boundary";
    stateNames[SPECIAL_INTERNAL_STATE_TOP] = "<top>";
    stateNames[SPECIAL_INTERNAL_STATE_UNVISITED] = "<uninitialized>";
    int i = 0;
    while( i < 1 )
        history[i++] = SPECIAL_INTERNAL_STATE_UNVISITED;
}









void Capsule_Ctrl2::bindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, true );
            break;
        case borderport_sensor2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor2, index, true );
            break;
        }
}

void Capsule_Ctrl2::unbindPort( bool isBorder, int portId, int index )
{
    if( isBorder )
        switch( portId )
        {
        case borderport_main:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_main, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_main], index );
            break;
        case borderport_sensor2:
            UMLRTFrameService::sendBoundUnbound( borderPorts, borderport_sensor2, index, false );
            UMLRTFrameService::disconnectPort( borderPorts[borderport_sensor2], index );
            break;
        }
}

void Capsule_Ctrl2::inject( const UMLRTMessage & message )
{
    msg = &message;
    switch( currentState )
    {
    case WorkingC2__WaitM:
        currentState = state_____WorkingC2__WaitM( &message );
        break;
    case WorkingC2__Countdown:
        currentState = state_____WorkingC2__Countdown( &message );
        break;
    case WorkingC2__boundary:
        currentState = state_____WorkingC2__boundary( &message );
        break;
    default:
        break;
    }
}

void Capsule_Ctrl2::initialize( const UMLRTMessage & message )
{
    msg = &message;
    actionchain_____Initial( &message );
    currentState = junction_____WorkingC2__connectionPoint0( &message );
}

const char * Capsule_Ctrl2::getCurrentStateString() const
{
    return stateNames[currentState];
}





void Capsule_Ctrl2::save_history( Capsule_Ctrl2::State compositeState, Capsule_Ctrl2::State subState )
{
    history[compositeState] = subState;
}

bool Capsule_Ctrl2::check_history( Capsule_Ctrl2::State compositeState, Capsule_Ctrl2::State subState )
{
    return history[compositeState] == subState;
}

void Capsule_Ctrl2::update_state( Capsule_Ctrl2::State newState )
{
    currentState = newState;
}

void Capsule_Ctrl2::transitionaction_____WorkingC2__startCtrl( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl2::WorkingC2 transition WorkingC2::WaitM,WorkingC2::Countdown,reply:main */
    log.log("Line 2 waits for loading slot");
    timingC2.informIn(UMLRTTimespec(10, 0)); 
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl2::transitionaction_____WorkingC2__transition0( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl2::WorkingC2 transition WorkingC2::connectionPoint0,WorkingC2::WaitM */
    log.log("Starting controller 2");
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl2::transitionaction_____WorkingC2__transition2( const UMLRTMessage * msg )
{
    #define rtdata ( (void *)msg->getParam( 0 ) )
    /* UMLRTGEN-USERREGION-BEGIN platform:/resource/ConveyorBelt/ConveyorBelt.uml ConveyorBelt::Ctrl2::WorkingC2 transition WorkingC2::Countdown,WorkingC2::WaitM,timeout:timingC2 */
    sensor2.confirm().send();
    /* UMLRTGEN-USERREGION-END */
    #undef rtdata
}

void Capsule_Ctrl2::actionchain_____Initial( const UMLRTMessage * msg )
{
    update_state( WorkingC2 );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__new_transition_1( const UMLRTMessage * msg )
{
    update_state( WorkingC2__WaitM );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__new_transition_2( const UMLRTMessage * msg )
{
    update_state( WorkingC2__Countdown );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__new_transition_3_to_unvisited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingC2__boundary );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__new_transition_4_to_visited_boundary( const UMLRTMessage * msg )
{
    update_state( WorkingC2__boundary );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__startCtrl( const UMLRTMessage * msg )
{
    update_state( WorkingC2 );
    transitionaction_____WorkingC2__startCtrl( msg );
    update_state( WorkingC2__Countdown );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__transition0( const UMLRTMessage * msg )
{
    transitionaction_____WorkingC2__transition0( msg );
    update_state( WorkingC2__WaitM );
}

void Capsule_Ctrl2::actionchain_____WorkingC2__transition2( const UMLRTMessage * msg )
{
    update_state( WorkingC2 );
    transitionaction_____WorkingC2__transition2( msg );
    update_state( WorkingC2__WaitM );
}

Capsule_Ctrl2::State Capsule_Ctrl2::junction_____WorkingC2__connectionPoint0( const UMLRTMessage * msg )
{
    actionchain_____WorkingC2__transition0( msg );
    return WorkingC2__WaitM;
}

Capsule_Ctrl2::State Capsule_Ctrl2::choice_____WorkingC2__deephistory( const UMLRTMessage * msg )
{
    if( check_history( WorkingC2, WorkingC2__WaitM ) )
    {
        actionchain_____WorkingC2__new_transition_1( msg );
        return WorkingC2__WaitM;
    }
    else if( check_history( WorkingC2, WorkingC2__Countdown ) )
    {
        actionchain_____WorkingC2__new_transition_2( msg );
        return WorkingC2__Countdown;
    }
    else if( check_history( WorkingC2, SPECIAL_INTERNAL_STATE_UNVISITED ) )
    {
        actionchain_____WorkingC2__new_transition_3_to_unvisited_boundary( msg );
        return WorkingC2__boundary;
    }
    else if( check_history( WorkingC2, WorkingC2__boundary ) )
    {
        actionchain_____WorkingC2__new_transition_4_to_visited_boundary( msg );
        return WorkingC2__boundary;
    }
    return currentState;
}

Capsule_Ctrl2::State Capsule_Ctrl2::state_____WorkingC2__Countdown( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_timingC2:
        switch( msg->getSignalId() )
        {
        case UMLRTTimerProtocol::signal_timeout:
            actionchain_____WorkingC2__transition2( msg );
            return WorkingC2__WaitM;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Ctrl2::State Capsule_Ctrl2::state_____WorkingC2__WaitM( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    case port_main:
        switch( msg->getSignalId() )
        {
        case ClientMain::signal_reply:
            actionchain_____WorkingC2__startCtrl( msg );
            return WorkingC2__Countdown;
        default:
            this->unexpectedMessage();
            break;
        }
        return currentState;
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}

Capsule_Ctrl2::State Capsule_Ctrl2::state_____WorkingC2__boundary( const UMLRTMessage * msg )
{
    switch( msg->destPort->role()->id )
    {
    default:
        this->unexpectedMessage();
        break;
    }
    return currentState;
}


static const UMLRTCommsPortRole portroles_border[] = 
{
    {
        Capsule_Ctrl2::port_main,
        "ClientMain",
        "main",
        "",
        1,
        true,
        false,
        false,
        false,
        false,
        false,
        true
    },
    {
        Capsule_Ctrl2::port_sensor2,
        "ClientClient",
        "sensor2",
        "",
        1,
        true,
        true,
        false,
        false,
        false,
        false,
        true
    }
};

static const UMLRTCommsPortRole portroles_internal[] = 
{
    {
        Capsule_Ctrl2::port_timingC2,
        "Timing",
        "timingC2",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    },
    {
        Capsule_Ctrl2::port_log,
        "Log",
        "log",
        "",
        0,
        false,
        false,
        false,
        false,
        true,
        false,
        false
    }
};

static void instantiate_Ctrl2( const UMLRTRtsInterface * rts, UMLRTSlot * slot, const UMLRTCommsPort * * borderPorts )
{
    const UMLRTCommsPort * * internalPorts = UMLRTFrameService::createInternalPorts( slot, &Ctrl2 );
    slot->capsule = new Capsule_Ctrl2( &Ctrl2, slot, borderPorts, internalPorts, false );
}

const UMLRTCapsuleClass Ctrl2 = 
{
    "Ctrl2",
    NULL,
    instantiate_Ctrl2,
    0,
    NULL,
    2,
    portroles_border,
    2,
    portroles_internal
};

