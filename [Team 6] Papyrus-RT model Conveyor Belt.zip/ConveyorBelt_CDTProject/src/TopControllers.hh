
#ifndef TOPCONTROLLERS_HH
#define TOPCONTROLLERS_HH

class UMLRTController;
struct UMLRTCommsPort;
struct UMLRTSlot;

enum CapsuleInstanceId
{
    InstId_Top,
    InstId_Top_ctrl1,
    InstId_Top_ctrl2,
    InstId_Top_mainCtrl,
    InstId_Top_sensor1,
    InstId_Top_sensor2
};
extern UMLRTController * DefaultController;
extern UMLRTCommsPort borderports_Top_ctrl1[];
extern UMLRTCommsPort internalports_Top_ctrl1[];
extern UMLRTCommsPort borderports_Top_ctrl2[];
extern UMLRTCommsPort internalports_Top_ctrl2[];
extern UMLRTCommsPort borderports_Top_mainCtrl[];
extern UMLRTCommsPort internalports_Top_mainCtrl[];
extern UMLRTCommsPort borderports_Top_sensor1[];
extern UMLRTCommsPort internalports_Top_sensor1[];
extern UMLRTCommsPort borderports_Top_sensor2[];
extern UMLRTCommsPort internalports_Top_sensor2[];
extern UMLRTSlot Top_slots[];

#endif

