
#ifndef TOP_HH
#define TOP_HH

#include "umlrtcapsule.hh"
#include "umlrtcapsuleclass.hh"
#include "umlrtmessage.hh"
struct UMLRTCapsulePart;
struct UMLRTCommsPort;
struct UMLRTSlot;

class Capsule_Top : public UMLRTCapsule
{
public:
    Capsule_Top( const UMLRTCapsuleClass * cd, UMLRTSlot * st, const UMLRTCommsPort * * border, const UMLRTCommsPort * * internal, bool isStat );
    enum PartId
    {
        part_ctrl1,
        part_ctrl2,
        part_mainCtrl,
        part_sensor1,
        part_sensor2
    };
protected:
    const UMLRTCapsulePart * const ctrl1;
    const UMLRTCapsulePart * const ctrl2;
    const UMLRTCapsulePart * const mainCtrl;
    const UMLRTCapsulePart * const sensor1;
    const UMLRTCapsulePart * const sensor2;
public:
    virtual void bindPort( bool isBorder, int portId, int index );
    virtual void unbindPort( bool isBorder, int portId, int index );
    virtual void initialize( const UMLRTMessage & msg );
    virtual void inject( const UMLRTMessage & msg );
};
extern const UMLRTCapsuleClass Top;

#endif

